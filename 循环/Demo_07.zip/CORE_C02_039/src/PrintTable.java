
public class PrintTable {

	public static void main(String[] args) {
		int i = 0;
		while (i < 10) {
			int j = 0;
			while (j < 10) {
				j++;
				System.out.printf("(" + i + "," + j + ")\t");
				
				}
			
			System.out.println();
			i++;
			}

	}

}
