
public class RoseException extends Exception{
	public RoseException() {
		super();
	}
	public RoseException(String str) {
		super(str);
	}
}
