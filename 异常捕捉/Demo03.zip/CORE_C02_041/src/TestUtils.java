
public class TestUtils {

	public static void main(String[] args) {
		int a = 4;
		int b = 3;
		System.out.println(Utils.add(a, b));
		System.out.println(Utils.substract(a, b));
		System.out.println(Utils.multiply(a, b));
		System.out.println(Utils.division(a, b));
	}

}
